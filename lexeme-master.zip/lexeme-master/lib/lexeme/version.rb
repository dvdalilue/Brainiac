module Lexeme
  VERSION = '0.0.5'
end
