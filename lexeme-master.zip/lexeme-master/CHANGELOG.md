Changelog
=========

0.0.4
-----

   #use_language

```ruby
lexer = Lexeme.define do
  use_language :natural
end
```
